################################################################################
# Automatically-generated file. Do not edit or delete the file
################################################################################

ADC\ADC.c

I2C\I2C.c

LCD\LCD.c

main.c

PWM\PWM.c

